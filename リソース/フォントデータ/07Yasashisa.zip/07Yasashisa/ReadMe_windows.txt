﻿07 やさしさゴシック
Copyright (C) 2002-2012 M+ FONTS PROJECT
Copyright(c) Information-technology Promotion Agency, Japan (IPA), 
2003-2012.
Copyright (C) 2012 Fontna.com

使用に当たって
-----------
フォントをインストールして頂くと、ワープロ、グラフィックソフトなどの
アプリケーションでこのフォントを使って自由にデザイン、印刷することができます。やさしさ溢れる文字デザインのフォントです。


概要
-----------

07 YasashisaGothic（やさしさゴシック）は、以下の2種類を合成したフォント
にオリジナルの文字を加え加工したOpenTypeフォントです。

* M+（エムプラス）フォント
* IPA（アイピーエー）ゴシック

ひらがな、カタカナをオリジナルで制作し、残りの部分をM+FONTで補いました。
またM+FONTで不足している漢字をIPAゴシックで補っています。
全体的なデザイン処理として、わずかに文字の角を丸く加工処理しています。
M+FONTおよびIPAゴシックの派生プログラムにあたります。


インストール
-----------
1.フォントをダウンロードしたら圧縮されたファイルを解凍します。
まず+Lhaca、StuffIt Expander、WinRAR、Lhaplus等の解凍ソフトを使用し
解凍してフォントファイルにして下さい。
2.フォントをパソコンにインストールします。
以下からお使いのパソコンのインストール方法に従ってください。
 
Windows7でのフォントのインストール
http://www.fontna.com/?page_id=106
 
WindowsXP〜7でのフォントのインストール
http://www.fontna.com/?page_id=157
 

ライセンス
----------
このフォントのライセンスは、
M+と、IPAフォントのライセンスに準じます。

M+のライセンスは、配布物に含まれる
「mplus-TESTFLIGHT-043」フォルダ内の書類をご覧ください。

IPAフォントのライセンスは、配布物に含まれる「ipag00303」フォルダの
IPA_Font_License_Agreement_v1.0.txtをご覧ください。

このフォントをIPAフォントに置き換える場合は、
以下のWebサイトで「IPAゴシック（Ver.003.03）」を入手してください。
http://ossipedia.ipa.go.jp/ipafont/


IPAフォントへの置き換え方（戻し方）
-----------
1.「07 YasashisaGothic」フォントのアンインストールを行ってください。
2.　http://ossipedia.ipa.go.jp/ipafont/　よりフォントをダウンロードしてください。または「IPAfont00303」フォルダ内のIPAゴシックを選択してください。
3.　IPAゴシックを必要に応じてインストールしてください。
詳しくは　http://www.fontna.com/?page_id=248


詳細
-----------

フォントの詳細、お問い合わせなどは以下の URL からお願いします。

フォントな
http://www.fontna.com/